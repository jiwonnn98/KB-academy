package dao;

import java.util.List;

public interface BannerDao {

	List<String> listBanner();
}
